﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using Finance_Tracker.Form_Design;

namespace Finance_Tracker
{
    internal class LoginDetails
    {
        //Add the initial data to the system
        string UserName, Password;

        public LoginDetails(string userName, string passord)
        {
            this.UserName = userName;
            this.Password = passord;
            
        }

        public string UserName1 { get => UserName; set => UserName = value; }
        public string Password1 { get => Password; set => Password = value; }

        //Validation method

        public void SignUp(string username, string password, string PassCon)
        {
            LoginApp login = new LoginApp();
            if (PassCon == password)
            {
                if (username.Contains(",") || password.Contains(',') || PassCon.Contains(",")) // username / pasword should not contain a comma
                {
                    MessageBox.Show("Comma is not allowed in either   Username or Password");
                }
                else
                {
                    login.WriteToFile(username, password);
                    MessageBox.Show($"{username}'s account has succefully been created");

                }
            }
            else
            {
                MessageBox.Show("Passwords don't match");
            }
        }
    }
}
