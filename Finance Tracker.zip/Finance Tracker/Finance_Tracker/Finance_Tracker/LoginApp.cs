﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Linq.Expressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Windows.Forms;
using Finance_Tracker.Form_Design;

namespace Finance_Tracker
{
    internal class LoginApp
    {
        //Create the textFile
        string DataFile = "User.txt";

        public void WriteToFile(string UserName, string Password)
        {
            using (StreamWriter writer = new StreamWriter(DataFile))
            {
                writer.WriteLine($"{UserName},{Password}");
            }
        }
        public Boolean Read(string UserName, string Password)
        {
            if (File.Exists(DataFile))
            {
                using (StreamReader reader = new StreamReader(DataFile))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length == 2)
                        {
                            string storedUserName = parts[0].Trim();
                            string storedPassword = parts[1].Trim();
                            if (UserName == storedUserName && Password == storedPassword)
                            {
                                MessageBox.Show($"Welcome {UserName}");
                                Main_Page page = new Main_Page();
                                page.Show();
                                return true;
                            }
                        }
                    }
                    MessageBox.Show("Invalid Username or Password");
                }
            }
            else
            {
                MessageBox.Show("File not found");
            }
            return false; // Login in attempt failed
        }
    }
}
