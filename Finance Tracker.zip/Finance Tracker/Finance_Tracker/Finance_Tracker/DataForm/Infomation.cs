﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Finance_Tracker.DataForm;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace Finance_Tracker.DataForm
{
    
    internal class Infomation
    {
        private DataTable stdDataTable = new DataTable();
        string connect = "Server=.; Initial Catalog= Finances; Integrated Security= SSPI";
        SqlDataAdapter adapter;
        DataTable table;

        int Total, ID;

        public DataTable getFinances()
        {
            string query = @"SELECT * FROM Record";
            adapter = new SqlDataAdapter(query, connect);
            table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        // One to show the balances: 
        public DataTable getHistory()
        {
            string query = @"SELECT Funds, Date FROM Record";
            adapter = new SqlDataAdapter(query, connect);
            table = new DataTable();
            adapter.Fill(table);

            return table;
        }
        // Gets the amount of entries through countin the IDs and using that data. 
        public int Entries()
        {
            string query = @"SELECT COUNT(ID) FROM Record";
            int count = 0;

            try
            {
                using (SqlConnection con = new SqlConnection(connect))
                {
                    using (SqlCommand comm = new SqlCommand(query, con))
                    {
                        con.Open();
                        count = (int)comm.ExecuteScalar();
                        //con.Close();
                    }
                }
            }
            catch (Exception)
            {
                throw; // You may want to handle or log the exception appropriately
            }

            return count;
        }
        public void Register(Finances finances)
        {
            finances.ID = Entries(); // Assuming this generates a unique ID
            string query = "INSERT INTO Record (ID, Category, Description, Cost, Funds, Date) " +
                           "VALUES (@ID, @Category, @Description, @Cost, @Funds, @Date)";

            try
            {
                using (SqlConnection con = new SqlConnection(connect))
                {
                    using (SqlCommand comm = new SqlCommand(query, con))
                    {
                        // Add parameters
                        comm.Parameters.AddWithValue("@ID", finances.ID);
                        comm.Parameters.AddWithValue("@Category", finances.Category);
                        comm.Parameters.AddWithValue("@Description", finances.Description);
                        comm.Parameters.AddWithValue("@Cost", finances.Cost);
                        comm.Parameters.AddWithValue("@Funds", finances.Funds);
                        comm.Parameters.AddWithValue("@Date", finances.Date);

                        con.Open();
                        comm.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public decimal GetTotal()
        {
            string query = $"SELECT TOP 1 Funds FROM Record ORDER BY ID DESC";
            decimal lastValue = 0;

            try
            {
                using (SqlConnection con = new SqlConnection(connect))
                {
                    using (SqlCommand comm = new SqlCommand(query, con))
                    {
                        con.Open();
                        lastValue = (decimal)comm.ExecuteScalar();
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle or log the exception appropriately
                throw new Exception("Error retrieving last value from database.", ex);
            }

            return lastValue;
        }

        public void Search(string category)
        {
            
            string query = $"SELECT * FROM Record WHERE Category = '{category}'";

            
        }

    }
}
