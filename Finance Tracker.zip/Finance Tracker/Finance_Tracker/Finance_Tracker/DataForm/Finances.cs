﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance_Tracker.DataForm
{
    class Finances
    {
        public Finances(int iD, string category, string description, decimal cost, decimal funds, DateTime date)
        {
            ID = iD;
            Category = category;
            Description = description;
            Cost = cost;
            Funds = funds;
            Date = date;
        }

        public int ID { get; set; }
        public string Category { get; set;  }
        public string Description { get; set; }
        public decimal Cost { get; set; }
        public decimal Funds { get; set; }
        public DateTime Date { get; set; }
    }

    
}
