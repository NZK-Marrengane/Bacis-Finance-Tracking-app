﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Finance_Tracker.DataForm;

namespace Finance_Tracker.Form_Design
{
    public partial class Finance_Tracking : Form
    {
        int indexRow;
        Infomation info = new Infomation();
        public Finance_Tracking()
        {
            InitializeComponent();
        }
        //Allows the user to access more details about each section of the data
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;

            DataGridViewRow row = DGVData.Rows[indexRow];

            txtID.Text = row.Cells[0].Value.ToString();
            txtType.Text = row.Cells[1].Value.ToString();
            txtDetails.Text = row.Cells[2].Value.ToString();
            txtCost.Text = row.Cells[3].Value.ToString();
            txtBalance.Text = row.Cells[4].Value.ToString();
            txtDate.Text = row.Cells[5].Value.ToString();
        }
        //Access the table
        private void Finance_Tracking_Load(object sender, EventArgs e)
        {
            DGVData.DataSource = info.getFinances();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectedColumn = cbSearch.SelectedItem.ToString();

            // Get the search term
            string searchTerm = txtSearch.Text;
            try
            {
                // Check if DataGridView is populated
                if (DGVData.DataSource is DataTable dataTable)
                {
                    // Perform search based on the selected column
                    if (dataTable.Columns.Contains(selectedColumn))
                    {
                        // Filter the rows based on search term and selected column
                        var filteredRows = dataTable.AsEnumerable()
                                                    .Where(row => row[selectedColumn].ToString().Contains(searchTerm))
                                                    .CopyToDataTable();

                        // Display the filtered rows in the DataGridView
                        DGVData.DataSource = filteredRows;
                    }
                    else
                    {
                        MessageBox.Show("Selected column does not exist.");
                    }

                }
            }catch (Exception) 
            {
                MessageBox.Show("Value doesn't exist");
            }
            DGVData.DataSource = info.getFinances();
        }

        private void txtView_Click(object sender, EventArgs e)
        {
            DGVData.DataSource = info.getFinances();
        }
    }
}
