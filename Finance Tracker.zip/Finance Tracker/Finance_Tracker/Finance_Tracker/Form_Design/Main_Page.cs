﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Finance_Tracker.Form_Design;

namespace Finance_Tracker.Form_Design
{
    public partial class Main_Page : Form
    {
        public Main_Page()
        {
            InitializeComponent();
        }

        private void btnSpending_Click(object sender, EventArgs e)
        {
            Finance_Spenditure spend = new Finance_Spenditure();
            spend.Show();
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {
            Finance_Tracking track = new Finance_Tracking();
            track.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Account account = new Account();
            account.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
