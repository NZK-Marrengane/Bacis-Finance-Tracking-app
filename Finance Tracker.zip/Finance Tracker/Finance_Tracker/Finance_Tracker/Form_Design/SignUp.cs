﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Finance_Tracker.DataForm;

namespace Finance_Tracker.Form_Design
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }
        LoginApp loginApp = new LoginApp();
       
        private void btnSignUp_Click(object sender, EventArgs e)
        {
            string UserName = txtUserName.Text;
            string Password = txtPassword.Text;
            string ConPass = txtPassCon.Text;

            LoginDetails details = new LoginDetails(UserName, Password);
            details.SignUp(UserName, Password, ConPass);

            loginApp.WriteToFile(UserName, Password);
            SignUp signUp = new SignUp();
            signUp.Hide();

        }
    }
}
