﻿using Finance_Tracker.DataForm;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Finance_Tracker.DataForm;

namespace Finance_Tracker.Form_Design
{
    public partial class Account : Form
    {
        Infomation info = new Infomation();
        DateTime Date = DateTime.Today;
        public Account()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal Balance = info.GetTotal();

            decimal value = Balance + decimal.Parse(txtDeposit.Text);
            Finances finances = new Finances(info.Entries(), "Deposit", "Icrease the funds in the account", decimal.Parse(txtDeposit.Text), value, Date);
            info.Register(finances);

            dataGridView1.DataSource = info.getHistory();

            MessageBox.Show($"New Total is: {Balance}");
        }

        private void Account_Load(object sender, EventArgs e)
        {
            //dataGridView1.DataSource = info.getFinances();
            dataGridView1.DataSource = info.getHistory();   
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            Main_Page main_Page = new Main_Page();  
            main_Page.Show();

            Account account = new Account();
            account.Hide();
        }
    }
}
