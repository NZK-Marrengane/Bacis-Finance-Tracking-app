﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Finance_Tracker.DataForm;

namespace Finance_Tracker.Form_Design
{
    public partial class Finance_Spenditure : Form
    {
        Infomation info = new Infomation();
        DateTime Date = DateTime.Today;

        public Finance_Spenditure()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Finance_Spenditure_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = info.getFinances();
            txtBalance.Text = info.GetTotal().ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            decimal Total = info.GetTotal();
            decimal value = Total - decimal.Parse(txtCost.Text);
           // MessageBox.Show($"{value}");
            
            Finances finances = new Finances(info.Entries(), cbCategory.Text, txtDescription.Text, decimal.Parse(txtCost.Text), value, Date);
            info.Register(finances);
            dataGridView1.DataSource = info.getFinances();
            txtBalance.Text = info.GetTotal().ToString();

            
            txtDescription.Clear();
            txtCost.Clear();

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main_Page page = new Main_Page();
            Finance_Spenditure financeSpend = new Finance_Spenditure();
            page.Show();
            financeSpend.Close();
        }
    }

    internal class TotalFunds
    {
    }
}
